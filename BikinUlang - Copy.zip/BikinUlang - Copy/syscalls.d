syscalls.o: D:\STM32\ IDE\ BANDHA\BikinUlang\Core\Src\syscalls.c
